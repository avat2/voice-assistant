from flask import Flask, request, render_template, jsonify
from google.cloud import texttospeech, speech
from twilio.twiml.voice_response import VoiceResponse
from twilio.rest import Client
import os

# Configuración de Google Cloud
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "credentials/your_google_cloud_credentials.json"

# Configuración de Twilio
account_sid = 'your_twilio_account_sid'
auth_token = 'your_twilio_auth_token'
twilio_number = 'your_twilio_phone_number'
client = Client(account_sid, auth_token)

app = Flask(__name__)

# Ruta para la página principal
@app.route('/')
def index():
    return render_template('index.html')

# Ruta para la generación de voz
@app.route('/generate_voice', methods=['POST'])
def generate_voice():
    data = request.json
    texto = data['text']

    client = texttospeech.TextToSpeechClient()
    input_text = texttospeech.SynthesisInput(text=texto)
    voice = texttospeech.VoiceSelectionParams(
        language_code="es-ES",
        ssml_gender=texttospeech.SsmlVoiceGender.FEMALE
    )
    audio_config = texttospeech.AudioConfig(audio_encoding=texttospeech.AudioEncoding.MP3)

    response = client.synthesize_speech(input=input_text, voice=voice, audio_config=audio_config)
    
    filename = "static/response.mp3"
    with open(filename, "wb") as out:
        out.write(response.audio_content)
    
    return jsonify({"audio_url": filename})

# Ruta para la transcripción de voz
@app.route('/transcribe_voice', methods=['POST'])
def transcribe_voice():
    if 'file' not in request.files:
        return jsonify({"error": "No file part"})
    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No selected file"})
    
    client = speech.SpeechClient()
    audio = speech.RecognitionAudio(content=file.read())
    config = speech.RecognitionConfig(
        encoding=speech.RecognitionConfig.AudioEncoding.LINEAR16,
        sample_rate_hertz=16000,
        language_code="es-ES"
    )
    response = client.recognize(config=config, audio=audio)

    transcription = ""
    for result in response.results:
        transcription += result.alternatives[0].transcript + " "
    
    return jsonify({"transcription": transcription.strip()})

# Ruta para hacer una llamada
@app.route('/make_call', methods=['POST'])
def make_call():
    data = request.json
    to_number = data['to']
    text_message = data['message']

    call = client.calls.create(
        twiml=f'<Response><Say>{text_message}</Say></Response>',
        to=to_number,
        from_=twilio_number
    )
    
    return jsonify({"call_sid": call.sid})

# Ruta para recibir llamadas
@app.route('/incoming_call', methods=['POST'])
def incoming_call():
    response = VoiceResponse()
    response.say("Hola, gracias por llamar. Por favor, diga su consulta después del tono.")
    response.record(max_length=30, action="/handle_recording")
    return str(response)

@app.route('/handle_recording', methods=['POST'])
def handle_recording():
    recording_url = request.form["RecordingUrl"]
    print(f"Grabación disponible en: {recording_url}")
    # Aquí puedes procesar la grabación o pasarla a tu sistema de ventas
    return "Gracias, hemos recibido su mensaje."

if __name__ == '__main__':
    app.run(debug=True)
