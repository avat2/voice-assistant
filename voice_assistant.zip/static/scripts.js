function generateVoice() {
    const text = $('#text_to_speech').val();
    $.ajax({
        url: '/generate_voice',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({ text: text }),
        success: function(response) {
            $('#audio_player').attr('src', response.audio_url);
        },
        error: function(error) {
            console.error('Error generating voice:', error);
        }
    });
}

function makeCall() {
    const phoneNumber = $('#phone_number').val();
    const message = $('#call_message').val();
    $.ajax({
        url: '/make_call',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({ to: phoneNumber, message: message }),
        success: function(response) {
            alert('Call initiated with SID: ' + response.call_sid);
        },
        error: function(error) {
            console.error('Error making call:', error);
        }
    });
}
